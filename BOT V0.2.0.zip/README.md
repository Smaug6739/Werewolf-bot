# Werewolf-bot
Un bot discord pour faire des parties de loup-garou
